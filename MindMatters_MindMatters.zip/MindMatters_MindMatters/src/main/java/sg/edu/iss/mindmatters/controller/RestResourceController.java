package sg.edu.iss.mindmatters.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import sg.edu.iss.mindmatters.model.DailyTips;
import sg.edu.iss.mindmatters.model.QuizOutcome;
import sg.edu.iss.mindmatters.model.Resource;
import sg.edu.iss.mindmatters.service.DailyTipsService;
import sg.edu.iss.mindmatters.service.QuizServices;
import sg.edu.iss.mindmatters.service.ResourceImplementation;
import sg.edu.iss.mindmatters.service.ResourceServices;

@RestController
@RequestMapping("rest")
public class RestResourceController {

	@Autowired
	ResourceServices rService;
	
	@Autowired
	QuizServices qService;
	
	@Autowired
	DailyTipsService dtService;
	
	@GetMapping("/list")
	List<Resource> getAllResources()
	{
		return rService.findAll();
	}
	
	@GetMapping("profile/{user}")
	QuizOutcome getOutcome(@PathVariable("user")String user)
	{
		System.out.println("json sent!");
		System.out.println(qService.findByUserName(user));
		QuizOutcome qo=new QuizOutcome(null,null,null);
		if(qService.findByUserName(user)!=null)
		{
		 qo=qService.findByUserName(user);}
		
		return  qo;
	}
	
	@GetMapping("/show")
	List<DailyTips> findAll()
	{
		return dtService.findAll();
	}
	
	@GetMapping("/tip")
	List<DailyTips> findTip()
	{
		return dtService.findTip();
	}
	
}

