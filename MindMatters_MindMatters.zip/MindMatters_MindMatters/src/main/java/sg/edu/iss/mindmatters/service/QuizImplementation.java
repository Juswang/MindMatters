package sg.edu.iss.mindmatters.service;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import sg.edu.iss.mindmatters.model.QuizOutcome;
import sg.edu.iss.mindmatters.model.User;
import sg.edu.iss.mindmatters.repo.QuizRepository;
import sg.edu.iss.mindmatters.repo.UserRepository;

@Service
@Transactional
public class QuizImplementation implements QuizServices{

	@Autowired
	QuizRepository qrepo;
	
	@Autowired
	UserRepository urepo;

	@Override
	//public void saveQuizOutcome(String outcome, User user, HttpSession session) {
		public void saveQuizOutcome(String outcome, User user) {
		if(user != null) {
				
			
			if(checkAttempt(user))
			{
				QuizOutcome qo = qrepo.findByUser(user.getId());
				qo.setNextQuiz(LocalDate.now().plusMonths(3));
				qo.setQuizOutcome(outcome);
				qrepo.save(qo);
			}
			else {
				QuizOutcome qo = new QuizOutcome(LocalDate.now().plusMonths(3), outcome, user);
				qrepo.save(qo);
			}
			//session.invalidate();
		}
		
	}

	@Override
	public User findUserById(long id) {

		return urepo.findById(id).get();
	}

	@Override
	public boolean checkAttempt(User user) {
		
		if(qrepo.findByUser(user.getId()) != null)
			return true;
		
		return false;
	}

	@Override
	public QuizOutcome findByUserName(String username) {
		return qrepo.findByUserName(username);
				//findAll().stream().filter(x->x.getUser().getUserName().equalsIgnoreCase(username)).map(x->x.getQuizOutcome()).toString();
	}
	

}
