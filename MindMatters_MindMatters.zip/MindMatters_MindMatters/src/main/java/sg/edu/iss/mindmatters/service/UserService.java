package sg.edu.iss.mindmatters.service;

import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Map;

import javax.mail.internet.InternetAddress;
import javax.transaction.Transactional;
import javax.validation.ConstraintViolationException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import sg.edu.iss.mindmatters.model.ConfirmationToken;
import sg.edu.iss.mindmatters.model.User;
import sg.edu.iss.mindmatters.repo.ConfirmationTokenRepository;
import sg.edu.iss.mindmatters.repo.UserRepository;

@Service
public class UserService {
	@Autowired
	private UserRepository userRepository;

	@Autowired
	private EmailSenderService emailSenderService;

	@Autowired
	private ConfirmationTokenService ctService;

	@Transactional
	public String registerUser(User newUser) {

		User user = userRepository.findByUserName(newUser.getUserName());

		if (user != null) {
			return "User with userName already exists!";
		} else {
			user = userRepository.findByEmail(newUser.getEmail());
			if (user != null) {
				return "Email address is already in use! \nTry an alternate email address";
			}

			user = userRepository.save(newUser);
			String subject = "Complete Registration!";
			String text = "To confirm your account, please click here : "
					+ "http://localhost:8080/users/confirm-account?token=";
			saveTokenAndSendEmail(user, subject, text);
			return "SUCCESS... Confirm email before you can log in";
		}
	}

	@Transactional
	public String confirmUser(String confirmationToken) {

		ConfirmationToken token = ctService.findConfirmationToken(confirmationToken, "verify");
		if (token != null) {
			User user = userRepository.findByUserName(token.getUser().getUserName());
			user.setEnabled(true);
			userRepository.save(user);
			ctService.delete(token);
			return "success";
		}

		return "invalid";
	}

	public User findByUserName(String user) {
		return userRepository.findByUserName(user);
	}

	@Transactional
	public String updateUser(User newUser) {
		BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
		User user = userRepository.findByEmail(newUser.getEmail());
		String response = "";
		if (user != null) {
			if (!passwordEncoder.matches(newUser.getPassword(), user.getPassword())
					&& !newUser.getPhone().equals(user.getPhone())) {
				String encodedPassword = passwordEncoder.encode(newUser.getPassword());
				newUser.setPassword(encodedPassword);
				user.setPhone(newUser.getPhone());
				user.setPassword(newUser.getPassword());
				response = "Password and Number Updated";
			} else if (!passwordEncoder.matches(newUser.getPassword(), user.getPassword())) {
				String encodedPassword = passwordEncoder.encode(newUser.getPassword());
				newUser.setPassword(encodedPassword);
				user.setPassword(newUser.getPassword());
				response = "Password Updated";
			} else {
				user.setPhone(newUser.getPhone());
				response = "Number Updated";
			}
			user = userRepository.save(user);
		} else {
			response = "User Not found";
		}
		return response;
	}

	@Transactional
	public String sendResetLink(User existingUser) {
		User user = userRepository.findByEmail(existingUser.getEmail());
		if (user != null) {
			String subject = "Reset Password!";
			String text = "To reset your password, please click the link below : "
					+ "\n The link is valid for 15 minutes only\n"
					+ "http://localhost:8080/users/reset-password?token=";
			saveTokenAndSendEmail(user, subject, text);
			return "SUCCESS... Check your email to reset the password";
		}
		return "User does not exists for the email id entered";

	}

	public void save(User user) {
		userRepository.save(user);

	}

	@Transactional
	public String updatePassword(ConfirmationToken ct) {
		ConfirmationToken newCt = ctService.findConfirmationToken(ct.getConfirmationToken(), "reset");
		if (newCt != null) {
			User user = newCt.getUser();
			BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
			String encodedPassword = passwordEncoder.encode(ct.getUser().getPassword());
			user.setPassword(encodedPassword);
			userRepository.save(user);
			ctService.delete(newCt);
			return "Password update Successful";
		}
		return "The link is invalid or broken! Try Again";
	}

	public void saveTokenAndSendEmail(User user, String subject, String text) {

		ConfirmationToken confirmationToken = new ConfirmationToken(user);
		ctService.save(confirmationToken);

		SimpleMailMessage mailMessage = new SimpleMailMessage();
		mailMessage.setTo(user.getEmail());
		mailMessage.setSubject(subject);
		mailMessage.setFrom("team1.sa51@gmail.com");
		mailMessage.setText(text + confirmationToken.getConfirmationToken());

		emailSenderService.sendEmail(mailMessage);

	}

	public void delete(User user) {
		userRepository.delete(user);
	}
}
