package sg.edu.iss.mindmatters.validation;

public interface Expensive {

}
