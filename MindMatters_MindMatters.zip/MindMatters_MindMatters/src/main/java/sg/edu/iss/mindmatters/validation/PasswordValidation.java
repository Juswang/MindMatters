package sg.edu.iss.mindmatters.validation;

public interface PasswordValidation {

}
