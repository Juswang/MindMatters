package sg.edu.iss.mindmatters;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MindMattersLoginApplicationTests {

	@Test
	void contextLoads() {
	}

}
